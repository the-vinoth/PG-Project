"""
plots.py
─────────────────────────────────────────────────────────────
All visualization utilities for the project.

Plots included:
  1.  Sentiment distribution (pie + bar)
  2.  Word cloud per brand
  3.  Engagement vs. sentiment scatter
  4.  Time-series demand trend per brand
  5.  Brand comparison bar chart
  6.  Demand spike markers on time series
  7.  ARIMA vs Prophet forecast comparison
  8.  Confusion matrix heatmap
  9.  BiLSTM training curves (loss + accuracy)
  10. t-SNE embedding visualisation
─────────────────────────────────────────────────────────────
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
from wordcloud import WordCloud
from pathlib import Path
from typing import List, Optional, Dict

from src.utils.config import (
    FIGURES_DIR, SENTIMENT_LABELS, SENTIMENT_COLORS,
    TARGET_BRAND, ALL_BRANDS, COL_BRAND_MENTION,
    COL_TIMESTAMP, COL_SENTIMENT, COL_DEMAND_SCORE
)
from src.utils.logger import logger

# ── Global style ──────────────────────────────────────────
plt.rcParams.update({
    "figure.facecolor"  : "#0f0f0f",
    "axes.facecolor"    : "#1a1a2e",
    "axes.edgecolor"    : "#444",
    "axes.labelcolor"   : "#e0e0e0",
    "xtick.color"       : "#aaa",
    "ytick.color"       : "#aaa",
    "text.color"        : "#e0e0e0",
    "grid.color"        : "#2a2a3e",
    "grid.linestyle"    : "--",
    "grid.alpha"        : 0.5,
    "font.family"       : "DejaVu Sans",
    "figure.dpi"        : 150,
})

BRAND_PALETTE = {
    "Samsung S26 Ultra" : "#00cfff",
    "iPhone 17"         : "#a8b2d8",
    "Pixel 9"           : "#64ffda",
    "OnePlus 12"        : "#ff6b6b",
    "Xiaomi 14"         : "#ffd166",
}

FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def _save(fig: plt.Figure, name: str) -> Path:
    path = FIGURES_DIR / f"{name}.png"
    fig.savefig(path, bbox_inches="tight", facecolor=fig.get_facecolor())
    logger.info(f"Figure saved → {path}")
    return path


# ── 1. Sentiment Distribution ─────────────────────────────

def plot_sentiment_distribution(df: pd.DataFrame, save: bool = True) -> plt.Figure:
    counts  = df[COL_SENTIMENT].map(SENTIMENT_LABELS).value_counts()
    colors  = [SENTIMENT_COLORS[label] for label in counts.index]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Sentiment Distribution", fontsize=16, fontweight="bold", color="#e0e0e0")

    # Pie
    axes[0].pie(
        counts.values, labels=counts.index, colors=colors,
        autopct="%1.1f%%", startangle=140,
        textprops={"color": "#e0e0e0", "fontsize": 11}
    )
    axes[0].set_title("Overall Proportion", fontsize=12)

    # Bar
    axes[1].bar(counts.index, counts.values, color=colors, edgecolor="#333", linewidth=0.5)
    axes[1].set_ylabel("Comment Count")
    axes[1].set_title("Absolute Counts")
    for i, v in enumerate(counts.values):
        axes[1].text(i, v + max(counts)*0.01, f"{v:,}", ha="center", fontsize=10, color="#e0e0e0")

    plt.tight_layout()
    if save:
        _save(fig, "sentiment_distribution")
    return fig


# ── 2. Word Cloud per Brand ───────────────────────────────

def plot_wordcloud(df: pd.DataFrame, brand: str, save: bool = True) -> plt.Figure:
    subset = df[df[COL_BRAND_MENTION] == brand]
    if subset.empty:
        logger.warning(f"No data for brand: {brand}")
        return None

    text   = " ".join(subset["Clean_Text"].dropna().tolist())
    color  = BRAND_PALETTE.get(brand, "#00cfff")

    wc = WordCloud(
        width=900, height=450, background_color="#0f0f0f",
        colormap="Blues", max_words=150, collocations=False,
    ).generate(text)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.imshow(wc, interpolation="bilinear")
    ax.axis("off")
    ax.set_title(f"Word Cloud — {brand}", fontsize=15, fontweight="bold", color=color, pad=10)
    fig.patch.set_facecolor("#0f0f0f")

    if save:
        _save(fig, f"wordcloud_{brand.replace(' ', '_')}")
    return fig


# ── 3. Engagement vs Sentiment Scatter ────────────────────

def plot_engagement_sentiment(df: pd.DataFrame, save: bool = True) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(10, 6))
    for brand in ALL_BRANDS:
        sub = df[df[COL_BRAND_MENTION] == brand]
        ax.scatter(
            sub["Engagement_Weight"], sub["Sentiment_Score"],
            c=BRAND_PALETTE.get(brand, "#aaa"), label=brand,
            alpha=0.4, s=12, edgecolors="none"
        )
    ax.set_xlabel("Engagement Weight (normalised)")
    ax.set_ylabel("Sentiment Score (VADER compound)")
    ax.set_title("Engagement vs. Sentiment — All Brands", fontsize=13, fontweight="bold")
    ax.axhline(0.05, color="#2ecc71", linestyle="--", alpha=0.7, label="Positive threshold")
    ax.axhline(-0.05, color="#e74c3c", linestyle="--", alpha=0.7, label="Negative threshold")
    ax.legend(fontsize=8, framealpha=0.2, loc="upper left")
    ax.grid(True)

    if save:
        _save(fig, "engagement_vs_sentiment")
    return fig


# ── 4. Demand Trend Over Time ─────────────────────────────

def plot_demand_trend(daily_df: pd.DataFrame, brands: Optional[List[str]] = None, save: bool = True) -> plt.Figure:
    brands = brands or ALL_BRANDS
    fig, ax = plt.subplots(figsize=(14, 6))

    for brand in brands:
        sub = daily_df[daily_df[COL_BRAND_MENTION] == brand].sort_values("Timestamp")
        if sub.empty:
            continue
        color = BRAND_PALETTE.get(brand, "#aaa")
        ax.plot(sub["Timestamp"], sub["Avg_Demand"], label=brand, color=color, linewidth=1.8)
        ax.fill_between(sub["Timestamp"], sub["Avg_Demand"], alpha=0.08, color=color)

    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=30, ha="right")
    ax.set_ylabel("Average Demand Score")
    ax.set_title("Daily Demand Trend — Brand Comparison", fontsize=14, fontweight="bold")
    ax.legend(fontsize=9, framealpha=0.2)
    ax.grid(True)

    if save:
        _save(fig, "demand_trend")
    return fig


# ── 5. Brand Comparison Bar Chart ─────────────────────────

def plot_brand_comparison(daily_df: pd.DataFrame, save: bool = True) -> plt.Figure:
    summary = daily_df.groupby(COL_BRAND_MENTION).agg(
        Avg_Demand=("Avg_Demand", "mean"),
        Total_Volume=("Comment_Volume", "sum")
    ).reset_index().sort_values("Avg_Demand", ascending=False)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle("Brand Performance Comparison", fontsize=15, fontweight="bold")

    colors = [BRAND_PALETTE.get(b, "#aaa") for b in summary[COL_BRAND_MENTION]]

    axes[0].barh(summary[COL_BRAND_MENTION], summary["Avg_Demand"], color=colors, edgecolor="#333")
    axes[0].set_xlabel("Average Demand Score")
    axes[0].set_title("Avg Demand Score per Brand")
    axes[0].invert_yaxis()

    axes[1].barh(summary[COL_BRAND_MENTION], summary["Total_Volume"], color=colors, edgecolor="#333", alpha=0.8)
    axes[1].set_xlabel("Total Comment Volume")
    axes[1].set_title("Comment Volume per Brand")
    axes[1].invert_yaxis()

    plt.tight_layout()
    if save:
        _save(fig, "brand_comparison")
    return fig


# ── 7. Forecast Chart ─────────────────────────────────────

def plot_forecast(
    historical: pd.Series,
    forecast_df: pd.DataFrame,
    brand: str,
    save: bool = True,
) -> plt.Figure:
    color = BRAND_PALETTE.get(brand, "#00cfff")

    fig, ax = plt.subplots(figsize=(14, 6))
    ax.plot(historical.index, historical.values, color=color, linewidth=1.8, label="Historical")
    ax.plot(forecast_df["ds"], forecast_df["Ensemble"], color="#ffd166",
            linewidth=2, linestyle="--", label="Forecast (Ensemble)")

    if "yhat_lower" in forecast_df.columns:
        ax.fill_between(
            forecast_df["ds"],
            forecast_df["yhat_lower"],
            forecast_df["yhat_upper"],
            color="#ffd166", alpha=0.15, label="Prophet CI"
        )

    ax.axvline(historical.index[-1], color="#aaa", linestyle=":", linewidth=1.2, label="Forecast Start")
    ax.set_title(f"Demand Forecast — {brand}", fontsize=14, fontweight="bold", color=color)
    ax.set_ylabel("Demand Score")
    ax.set_xlabel("Date")
    ax.legend(fontsize=9, framealpha=0.2)
    ax.grid(True)
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=30, ha="right")

    if save:
        _save(fig, f"forecast_{brand.replace(' ', '_')}")
    return fig


# ── 8. Confusion Matrix ───────────────────────────────────

def plot_confusion_matrix(y_true, y_pred, save: bool = True) -> plt.Figure:
    from sklearn.metrics import confusion_matrix
    labels = list(SENTIMENT_LABELS.values())  # Negative, Neutral, Positive
    cm     = confusion_matrix(y_true, y_pred)

    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=labels, yticklabels=labels,
        ax=ax, linewidths=0.5, cbar=True,
        annot_kws={"size": 13}
    )
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label", fontsize=12)
    ax.set_title("Confusion Matrix — BiLSTM", fontsize=14, fontweight="bold")

    if save:
        _save(fig, "confusion_matrix")
    return fig


# ── 9. Training History ───────────────────────────────────

def plot_training_history(history_dict: dict, save: bool = True) -> plt.Figure:
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("BiLSTM Training History", fontsize=15, fontweight="bold")

    for ax, metric, ylabel in zip(
        axes,
        [("loss", "val_loss"), ("accuracy", "val_accuracy")],
        ["Loss", "Accuracy"]
    ):
        train_key, val_key = metric
        if train_key in history_dict:
            ax.plot(history_dict[train_key],  color="#00cfff", label="Train", linewidth=2)
        if val_key in history_dict:
            ax.plot(history_dict[val_key],    color="#ffd166", label="Validation", linewidth=2)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.set_title(f"Model {ylabel}")
        ax.legend(framealpha=0.2)
        ax.grid(True)

    plt.tight_layout()
    if save:
        _save(fig, "training_history")
    return fig


# ── 10. t-SNE Word Embedding Visualisation ────────────────

def plot_tsne_embeddings(w2v_model, words: Optional[List[str]] = None, save: bool = True) -> plt.Figure:
    from sklearn.manifold import TSNE

    if words is None:
        # Use top 200 most frequent words
        words = [w for w in list(w2v_model.wv.key_to_index.keys())[:200]]

    vectors = np.array([w2v_model.wv[w] for w in words if w in w2v_model.wv])
    labels  = [w for w in words if w in w2v_model.wv]

    logger.info(f"Running t-SNE on {len(vectors)} word vectors ...")
    tsne    = TSNE(n_components=2, perplexity=30, random_state=42, n_iter=1000)
    reduced = tsne.fit_transform(vectors)

    fig, ax = plt.subplots(figsize=(14, 10))
    ax.scatter(reduced[:, 0], reduced[:, 1], s=8, c="#00cfff", alpha=0.5)

    for i, label in enumerate(labels[:100]):  # Annotate first 100 only
        ax.annotate(label, (reduced[i, 0], reduced[i, 1]),
                    fontsize=7, alpha=0.75, color="#e0e0e0")

    ax.set_title("t-SNE Visualisation — Word2Vec Embeddings", fontsize=14, fontweight="bold")
    ax.axis("off")

    if save:
        _save(fig, "tsne_embeddings")
    return fig
