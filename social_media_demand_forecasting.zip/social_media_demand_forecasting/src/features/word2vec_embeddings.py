"""
word2vec_embeddings.py
─────────────────────────────────────────────────────────────
Word2Vec Skip-gram embedding training and inference utilities.

Responsibilities:
  - Train Word2Vec on the preprocessed token corpus
  - Build the embedding matrix for the BiLSTM's Embedding layer
  - Provide word similarity and analogy query helpers
  - Visualise embeddings with t-SNE / PCA
─────────────────────────────────────────────────────────────
"""

import numpy as np
import pandas as pd
from pathlib import Path
from typing import List, Dict, Optional, Tuple

from gensim.models import Word2Vec
from gensim.models.callbacks import CallbackAny2Vec

from src.utils.config import (
    W2V_EMBEDDING_DIM, W2V_WINDOW, W2V_MIN_COUNT, W2V_WORKERS,
    W2V_EPOCHS, W2V_MODEL_FILE, COL_TOKENS, VOCAB_SIZE, RANDOM_SEED
)
from src.utils.logger import logger


# ═══════════════════════════════════════════════════════════
#  Training Callback — epoch-level loss logging
# ═══════════════════════════════════════════════════════════

class _EpochLogger(CallbackAny2Vec):
    def __init__(self):
        self.epoch = 0

    def on_epoch_end(self, model):
        loss = model.get_latest_training_loss()
        self.epoch += 1
        logger.debug(f"  Word2Vec epoch {self.epoch}/{W2V_EPOCHS} | loss: {loss:.4f}")


# ═══════════════════════════════════════════════════════════
#  Training
# ═══════════════════════════════════════════════════════════

def train_word2vec(
    token_corpus: List[List[str]],
    save: bool = True,
) -> Word2Vec:
    """
    Train a Skip-gram Word2Vec model on the token corpus.

    Parameters
    ----------
    token_corpus : List of tokenised documents.
    save         : Save the model to W2V_MODEL_FILE.

    Returns
    -------
    gensim.models.Word2Vec
    """
    logger.info(f"Training Word2Vec | dim={W2V_EMBEDDING_DIM} | window={W2V_WINDOW} | epochs={W2V_EPOCHS}")
    logger.info(f"Corpus size: {len(token_corpus):,} documents")

    model = Word2Vec(
        sentences   = token_corpus,
        vector_size = W2V_EMBEDDING_DIM,
        window      = W2V_WINDOW,
        min_count   = W2V_MIN_COUNT,
        workers     = W2V_WORKERS,
        sg          = 1,          # Skip-gram
        hs          = 0,          # Negative sampling
        negative    = 5,
        seed        = RANDOM_SEED,
        epochs      = W2V_EPOCHS,
        callbacks   = [_EpochLogger()],
        compute_loss= True,
    )

    logger.success(f"Word2Vec trained. Vocabulary size: {len(model.wv):,} words")

    if save:
        W2V_MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
        model.save(str(W2V_MODEL_FILE))
        logger.success(f"Word2Vec model saved → {W2V_MODEL_FILE}")

    return model


def load_word2vec(filepath: Path = W2V_MODEL_FILE) -> Word2Vec:
    """Load a pre-trained Word2Vec model from disk."""
    if not filepath.exists():
        raise FileNotFoundError(f"Word2Vec model not found at {filepath}. Train first.")
    logger.info(f"Loading Word2Vec model from {filepath}")
    return Word2Vec.load(str(filepath))


# ═══════════════════════════════════════════════════════════
#  Tokenizer & Vocabulary
# ═══════════════════════════════════════════════════════════

def build_tokenizer(
    token_corpus: List[List[str]],
    vocab_size: int = VOCAB_SIZE,
) -> Dict[str, int]:
    """
    Build a word → integer index mapping from the corpus.
    Index 0 is reserved for padding.
    Index 1 is reserved for <UNK>.

    Returns
    -------
    dict : word → index
    """
    from collections import Counter
    freq = Counter(word for doc in token_corpus for word in doc)
    # Keep top vocab_size - 2 words (reserve 0=pad, 1=unk)
    top_words = [word for word, _ in freq.most_common(vocab_size - 2)]
    word2idx = {word: idx + 2 for idx, word in enumerate(top_words)}
    word2idx["<PAD>"] = 0
    word2idx["<UNK>"] = 1
    logger.info(f"Tokenizer built. Vocabulary: {len(word2idx):,} tokens")
    return word2idx


def build_embedding_matrix(
    word2idx: Dict[str, int],
    w2v_model: Word2Vec,
) -> np.ndarray:
    """
    Build a (vocab_size × embedding_dim) matrix for Keras Embedding layer.
    Words not found in Word2Vec are initialised with a small random vector.

    Returns
    -------
    np.ndarray : shape (vocab_size, W2V_EMBEDDING_DIM)
    """
    vocab_size = len(word2idx)
    matrix = np.zeros((vocab_size, W2V_EMBEDDING_DIM), dtype=np.float32)

    hits, misses = 0, 0
    for word, idx in word2idx.items():
        if word in w2v_model.wv:
            matrix[idx] = w2v_model.wv[word]
            hits += 1
        else:
            matrix[idx] = np.random.normal(scale=0.1, size=W2V_EMBEDDING_DIM)
            misses += 1

    logger.info(f"Embedding matrix built | hits={hits:,} | misses={misses:,} | coverage={hits/(hits+misses)*100:.1f}%")
    return matrix


def encode_sequences(
    token_docs: List[List[str]],
    word2idx: Dict[str, int],
    max_len: int,
) -> np.ndarray:
    """
    Convert token lists to zero-padded integer sequences.

    Returns
    -------
    np.ndarray : shape (n_docs, max_len)
    """
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    sequences = [[word2idx.get(w, 1) for w in doc] for doc in token_docs]
    padded    = pad_sequences(sequences, maxlen=max_len, padding="post", truncating="post")
    return padded


# ═══════════════════════════════════════════════════════════
#  Similarity Utilities
# ═══════════════════════════════════════════════════════════

def most_similar_words(w2v_model: Word2Vec, word: str, topn: int = 10) -> List[Tuple[str, float]]:
    """Return top-N most similar words for a given word."""
    if word not in w2v_model.wv:
        logger.warning(f"'{word}' not in Word2Vec vocabulary.")
        return []
    return w2v_model.wv.most_similar(word, topn=topn)


def brand_similarity(w2v_model: Word2Vec, brands: List[str]) -> pd.DataFrame:
    """
    Compute pairwise cosine similarity between brand keyword vectors.
    Useful for detecting brand migration signals.
    """
    from itertools import combinations
    rows = []
    for b1, b2 in combinations(brands, 2):
        b1_key = b1.lower().replace(" ", "")
        b2_key = b2.lower().replace(" ", "")
        try:
            sim = w2v_model.wv.similarity(b1_key, b2_key)
        except KeyError:
            sim = np.nan
        rows.append({"Brand_A": b1, "Brand_B": b2, "Cosine_Similarity": round(sim, 4)})
    return pd.DataFrame(rows).sort_values("Cosine_Similarity", ascending=False)


if __name__ == "__main__":
    from src.data.ingestion import load_sample
    from src.data.preprocessing import preprocess_dataframe

    df = load_sample()
    df = preprocess_dataframe(df, save=False)

    corpus = df[COL_TOKENS].tolist()
    w2v    = train_word2vec(corpus)

    print("\nTop 10 words similar to 'samsung':")
    for word, score in most_similar_words(w2v, "samsung"):
        print(f"  {word:<20} {score:.4f}")
