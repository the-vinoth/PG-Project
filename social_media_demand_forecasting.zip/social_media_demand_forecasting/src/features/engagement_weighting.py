"""
engagement_weighting.py
─────────────────────────────────────────────────────────────
Engagement-based demand signal amplification.

A comment with 5,000 likes praising the S26 Ultra carries
far more demand signal than a comment with 2 likes.
This module computes engagement-weighted sentiment scores
that feed directly into the demand forecasting layer.
─────────────────────────────────────────────────────────────
"""

import numpy as np
import pandas as pd
from typing import Optional

from src.utils.config import (
    COL_SENTIMENT_SCORE, COL_ENGAGEMENT_WEIGHT, COL_BRAND_MENTION,
    COL_TIMESTAMP, COL_DEMAND_SCORE, LIKE_WEIGHT, REPLY_WEIGHT,
    ENGAGEMENT_SCALE_CAP, TIME_AGGREGATION
)
from src.utils.logger import logger


def compute_demand_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the weighted demand score for each comment:

        demand_score = sentiment_score × (1 + engagement_weight)

    A neutral or negative engagement boosts/penalises proportionally.
    """
    if COL_SENTIMENT_SCORE not in df.columns:
        raise ValueError(f"Missing column: {COL_SENTIMENT_SCORE}. Run preprocessing first.")
    if COL_ENGAGEMENT_WEIGHT not in df.columns:
        raise ValueError(f"Missing column: {COL_ENGAGEMENT_WEIGHT}. Run preprocessing first.")

    df[COL_DEMAND_SCORE] = (
        df[COL_SENTIMENT_SCORE] * (1 + df[COL_ENGAGEMENT_WEIGHT])
    ).round(6)

    logger.info(f"Demand scores computed. Range: [{df[COL_DEMAND_SCORE].min():.4f}, {df[COL_DEMAND_SCORE].max():.4f}]")
    return df


def aggregate_demand_by_brand(
    df: pd.DataFrame,
    freq: str = TIME_AGGREGATION,
) -> pd.DataFrame:
    """
    Aggregate demand scores by brand and time window.

    Parameters
    ----------
    df   : DataFrame with COL_DEMAND_SCORE, COL_BRAND_MENTION, COL_TIMESTAMP.
    freq : Pandas time frequency ('D' = daily, 'W' = weekly).

    Returns
    -------
    pd.DataFrame : Multi-indexed time-series of demand by brand.
    """
    df = df.copy()
    df[COL_TIMESTAMP] = pd.to_datetime(df[COL_TIMESTAMP])
    df = df.set_index(COL_TIMESTAMP)

    result = (
        df.groupby(COL_BRAND_MENTION)
          .resample(freq)[COL_DEMAND_SCORE]
          .agg(["mean", "sum", "count"])
          .rename(columns={"mean": "Avg_Demand", "sum": "Total_Demand", "count": "Comment_Volume"})
          .reset_index()
    )

    logger.info(f"Demand aggregated at '{freq}' frequency. Shape: {result.shape}")
    return result


def detect_demand_spikes(
    daily_df: pd.DataFrame,
    brand: str,
    z_threshold: float = 2.0,
) -> pd.DataFrame:
    """
    Detect abnormal demand spikes using Z-score method.

    Parameters
    ----------
    daily_df    : Output of aggregate_demand_by_brand().
    brand       : Brand to analyse.
    z_threshold : Rows with |Z| > threshold are flagged as spikes.

    Returns
    -------
    pd.DataFrame : Spike events for the given brand.
    """
    brand_df = daily_df[daily_df[COL_BRAND_MENTION] == brand].copy()
    mean = brand_df["Avg_Demand"].mean()
    std  = brand_df["Avg_Demand"].std()

    if std == 0:
        logger.warning(f"Zero std for brand '{brand}' — cannot detect spikes.")
        return pd.DataFrame()

    brand_df["Z_Score"] = (brand_df["Avg_Demand"] - mean) / std
    spikes = brand_df[brand_df["Z_Score"].abs() > z_threshold]

    logger.info(f"[{brand}] Detected {len(spikes)} demand spike(s) (|Z| > {z_threshold})")
    return spikes


def compute_relative_demand_share(
    daily_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Compute each brand's % share of total daily demand.

    Returns
    -------
    pd.DataFrame : With an additional 'Demand_Share_%' column.
    """
    daily_totals = (
        daily_df.groupby(COL_TIMESTAMP)["Total_Demand"]
                .transform("sum")
    )
    daily_df = daily_df.copy()
    daily_df["Demand_Share_%"] = (daily_df["Total_Demand"] / daily_totals * 100).round(2)
    return daily_df


if __name__ == "__main__":
    from src.data.ingestion import load_sample
    from src.data.preprocessing import preprocess_dataframe

    df = load_sample()
    df = preprocess_dataframe(df, save=False)
    df = compute_demand_score(df)

    agg = aggregate_demand_by_brand(df)
    print(agg.head(20))

    spikes = detect_demand_spikes(agg, brand="Samsung S26 Ultra")
    print("Spike events:\n", spikes)
