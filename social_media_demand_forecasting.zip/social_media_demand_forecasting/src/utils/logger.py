"""
logger.py
─────────────────────────────────────────────────────────────
Centralized logging configuration using Loguru.
Import `logger` from this module across all project files
for consistent, colour-coded, file-persisted logging.
─────────────────────────────────────────────────────────────
"""

import sys
from loguru import logger
from src.utils.config import LOG_LEVEL, LOG_FILE

# Remove default Loguru handler
logger.remove()

# ── Console Handler (coloured) ─────────────────────────────
logger.add(
    sys.stderr,
    level=LOG_LEVEL,
    colorize=True,
    format=(
        "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> — "
        "<level>{message}</level>"
    ),
)

# ── File Handler (persistent) ──────────────────────────────
logger.add(
    str(LOG_FILE),
    level="DEBUG",
    rotation="10 MB",
    retention="14 days",
    compression="zip",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} — {message}",
)

__all__ = ["logger"]
