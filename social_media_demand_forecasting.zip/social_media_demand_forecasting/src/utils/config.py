"""
config.py
─────────────────────────────────────────────────────────────
Central configuration file for the Social Media Demand
Forecasting project.

All paths, hyperparameters, and global constants are defined
here so that every module imports from a single source of
truth — no hardcoded paths scattered across files.
─────────────────────────────────────────────────────────────
"""

import os
from pathlib import Path

# ─── Root Paths ────────────────────────────────────────────
ROOT_DIR        = Path(__file__).resolve().parents[2]
DATA_DIR        = ROOT_DIR / "data"
RAW_DIR         = DATA_DIR / "raw"
PROCESSED_DIR   = DATA_DIR / "processed"
SAMPLE_DIR      = DATA_DIR / "samples"

MODELS_DIR      = ROOT_DIR / "models" / "saved"
CHECKPOINTS_DIR = ROOT_DIR / "models" / "checkpoints"

OUTPUTS_DIR     = ROOT_DIR / "outputs"
FIGURES_DIR     = OUTPUTS_DIR / "figures"
PREDICTIONS_DIR = OUTPUTS_DIR / "predictions"
METRICS_DIR     = OUTPUTS_DIR / "metrics"

REPORTS_DIR     = ROOT_DIR / "reports"
NOTEBOOKS_DIR   = ROOT_DIR / "notebooks"

# Auto-create output directories if missing
for _dir in [PROCESSED_DIR, SAMPLE_DIR, MODELS_DIR, CHECKPOINTS_DIR,
             FIGURES_DIR, PREDICTIONS_DIR, METRICS_DIR,
             REPORTS_DIR / "figures", REPORTS_DIR / "final"]:
    _dir.mkdir(parents=True, exist_ok=True)

# ─── Dataset File Names ────────────────────────────────────
RAW_DATA_FILE       = RAW_DIR / "social_media_comments_1_6M.csv"
SAMPLE_FILE         = SAMPLE_DIR / "sample_10k.csv"
PROCESSED_TRAIN     = PROCESSED_DIR / "train_processed.csv"
PROCESSED_TEST      = PROCESSED_DIR / "test_processed.csv"
PROCESSED_FULL      = PROCESSED_DIR / "full_processed.csv"

# ─── Column Names ─────────────────────────────────────────
COL_TIMESTAMP       = "Timestamp"
COL_RAW_COMMENT     = "Raw_Comment"
COL_ENGAGEMENT      = "Engagement_Metrics"
COL_BRAND_MENTION   = "Brand_Mention"
COL_CLEAN_TEXT      = "Clean_Text"
COL_TOKENS          = "Tokens"
COL_SENTIMENT       = "Sentiment_Label"
COL_SENTIMENT_SCORE = "Sentiment_Score"
COL_ENGAGEMENT_WEIGHT = "Engagement_Weight"
COL_DEMAND_SCORE    = "Demand_Score"

# ─── Target Brands ────────────────────────────────────────
TARGET_BRAND        = "Samsung S26 Ultra"
COMPETITOR_BRANDS   = ["iPhone 17", "Pixel 9", "OnePlus 12", "Xiaomi 14"]
ALL_BRANDS          = [TARGET_BRAND] + COMPETITOR_BRANDS

BRAND_KEYWORDS = {
    "Samsung S26 Ultra": ["s26 ultra", "samsung s26", "galaxy s26", "s26ultra"],
    "iPhone 17":         ["iphone 17", "apple iphone17", "iphone17"],
    "Pixel 9":           ["pixel 9", "google pixel9", "pixel9"],
    "OnePlus 12":        ["oneplus 12", "oneplus12", "1+ 12"],
    "Xiaomi 14":         ["xiaomi 14", "xiaomi14", "mi 14"],
}

# ─── Preprocessing ────────────────────────────────────────
MAX_SEQUENCE_LENGTH = 128
VOCAB_SIZE          = 50_000
SAMPLE_SIZE         = 10_000
RANDOM_SEED         = 42
TEST_SPLIT          = 0.15
VAL_SPLIT           = 0.10

NLTK_STOPWORDS_LANG = "english"

# ─── Word2Vec Hyperparameters ──────────────────────────────
W2V_EMBEDDING_DIM   = 300
W2V_WINDOW          = 5
W2V_MIN_COUNT       = 5
W2V_WORKERS         = 4
W2V_EPOCHS          = 20
W2V_MODEL_FILE      = MODELS_DIR / "word2vec_300d.model"

# ─── BiLSTM Hyperparameters ───────────────────────────────
BILSTM_UNITS        = 128
BILSTM_DROPOUT      = 0.3
BILSTM_RECURRENT_DROPOUT = 0.2
BILSTM_DENSE_UNITS  = 64
NUM_CLASSES         = 3          # Positive / Negative / Neutral
BATCH_SIZE          = 256
EPOCHS              = 30
LEARNING_RATE       = 1e-3
EARLY_STOPPING_PATIENCE = 5
BILSTM_MODEL_FILE   = MODELS_DIR / "bilstm_sentiment_model.h5"

# ─── Sentiment Label Mapping ──────────────────────────────
SENTIMENT_LABELS    = {0: "Negative", 1: "Neutral", 2: "Positive"}
SENTIMENT_COLORS    = {"Positive": "#2ecc71", "Neutral": "#f39c12", "Negative": "#e74c3c"}

# ─── Forecasting ──────────────────────────────────────────
FORECAST_HORIZON_DAYS  = 30
TIME_AGGREGATION       = "D"   # 'D' = Daily, 'W' = Weekly
ARIMA_ORDER            = (2, 1, 2)
PROPHET_SEASONALITY    = "weekly"

# ─── Engagement Weighting ─────────────────────────────────
LIKE_WEIGHT            = 0.7
REPLY_WEIGHT           = 0.3
ENGAGEMENT_SCALE_CAP   = 10_000   # Cap extreme outliers

# ─── Logging ──────────────────────────────────────────────
LOG_LEVEL              = "INFO"
LOG_FILE               = ROOT_DIR / "outputs" / "pipeline.log"
