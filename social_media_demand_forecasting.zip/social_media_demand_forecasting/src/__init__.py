"""
Social Media Big Data Analysis for Demand Forecasting
======================================================
M.Sc. Data Science Project — Public Package API
"""

from src.data.ingestion import load_sample, load_raw_data, create_stratified_sample
from src.data.preprocessing import preprocess_dataframe, clean_text, full_pipeline
from src.features.word2vec_embeddings import (
    train_word2vec, load_word2vec, build_tokenizer,
    build_embedding_matrix, encode_sequences,
)
from src.features.engagement_weighting import (
    compute_demand_score, aggregate_demand_by_brand,
    detect_demand_spikes, compute_relative_demand_share,
)
from src.models.bilstm_model import build_bilstm_model, train_model, load_bilstm_model
from src.models.sentiment_classifier import SentimentClassifier, get_classifier
from src.models.demand_forecaster import run_brand_forecast, run_all_brand_forecasts
from src.utils.logger import logger
