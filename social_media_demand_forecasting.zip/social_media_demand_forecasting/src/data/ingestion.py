"""
ingestion.py
─────────────────────────────────────────────────────────────
Data loading, validation, and stratified sampling utilities.

Handles:
  - Loading raw 1.6M CSV efficiently with chunking
  - Stratified 10k sample generation
  - Basic schema validation
  - Memory-optimised dtype assignment
─────────────────────────────────────────────────────────────
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional

from src.utils.config import (
    RAW_DATA_FILE, SAMPLE_FILE, PROCESSED_DIR,
    COL_TIMESTAMP, COL_RAW_COMMENT, COL_ENGAGEMENT, COL_BRAND_MENTION,
    SAMPLE_SIZE, RANDOM_SEED
)
from src.utils.logger import logger

# ── Required columns ──────────────────────────────────────
REQUIRED_COLUMNS = [COL_TIMESTAMP, COL_RAW_COMMENT, COL_ENGAGEMENT, COL_BRAND_MENTION]

# ── Optimised dtypes for memory efficiency ────────────────
DTYPE_MAP = {
    COL_RAW_COMMENT:   "string",
    COL_BRAND_MENTION: "category",
    COL_ENGAGEMENT:    "int32",
}


def load_raw_data(
    filepath: Path = RAW_DATA_FILE,
    chunksize: int = 100_000,
    nrows: Optional[int] = None,
) -> pd.DataFrame:
    """
    Load the raw 1.6M CSV with chunked reading for memory efficiency.

    Parameters
    ----------
    filepath  : Path to the raw CSV file.
    chunksize : Rows per chunk (default 100k).
    nrows     : If set, only load this many rows (useful for testing).

    Returns
    -------
    pd.DataFrame : Full dataset with optimised dtypes.
    """
    logger.info(f"Loading raw data from: {filepath}")

    if not filepath.exists():
        raise FileNotFoundError(
            f"Raw data file not found at {filepath}.\n"
            f"Please place your dataset at: {filepath}"
        )

    chunks = []
    total_rows = 0

    reader = pd.read_csv(
        filepath,
        chunksize=chunksize,
        nrows=nrows,
        low_memory=False,
        parse_dates=[COL_TIMESTAMP],
    )

    for i, chunk in enumerate(reader):
        chunk = _validate_and_cast(chunk)
        chunks.append(chunk)
        total_rows += len(chunk)
        logger.debug(f"  Loaded chunk {i+1} | cumulative rows: {total_rows:,}")

    df = pd.concat(chunks, ignore_index=True)
    logger.success(f"Raw data loaded: {len(df):,} rows × {df.shape[1]} columns")
    _print_summary(df)
    return df


def load_sample(filepath: Path = SAMPLE_FILE) -> pd.DataFrame:
    """
    Load the pre-extracted 10,000-row development sample.

    Returns
    -------
    pd.DataFrame
    """
    logger.info(f"Loading 10k stratified sample from: {filepath}")

    if not filepath.exists():
        logger.warning("Sample file not found. Generating sample from raw data...")
        df_raw = load_raw_data()
        return create_stratified_sample(df_raw, save=True)

    df = pd.read_csv(filepath, parse_dates=[COL_TIMESTAMP], low_memory=False)
    df = _validate_and_cast(df)
    logger.success(f"Sample loaded: {len(df):,} rows")
    return df


def create_stratified_sample(
    df: pd.DataFrame,
    n: int = SAMPLE_SIZE,
    stratify_col: str = COL_BRAND_MENTION,
    save: bool = True,
) -> pd.DataFrame:
    """
    Generate a stratified random sample preserving brand_mention distribution.

    Parameters
    ----------
    df           : Full dataset.
    n            : Target sample size (default 10,000).
    stratify_col : Column to stratify on.
    save         : Whether to persist the sample to disk.

    Returns
    -------
    pd.DataFrame : Stratified sample.
    """
    logger.info(f"Creating stratified sample of {n:,} rows on '{stratify_col}' ...")

    # Proportional allocation per stratum
    counts = df[stratify_col].value_counts(normalize=True) * n
    counts = counts.round().astype(int)

    frames = []
    for brand, count in counts.items():
        stratum = df[df[stratify_col] == brand]
        sample_count = min(count, len(stratum))
        frames.append(stratum.sample(n=sample_count, random_state=RANDOM_SEED))

    sample_df = pd.concat(frames, ignore_index=True).sample(frac=1, random_state=RANDOM_SEED)

    logger.info(f"Sample distribution:\n{sample_df[stratify_col].value_counts()}")

    if save:
        SAMPLE_FILE.parent.mkdir(parents=True, exist_ok=True)
        sample_df.to_csv(SAMPLE_FILE, index=False)
        logger.success(f"Sample saved → {SAMPLE_FILE}")

    return sample_df


# ── Internal helpers ──────────────────────────────────────

def _validate_and_cast(df: pd.DataFrame) -> pd.DataFrame:
    """Validate required columns and apply memory-efficient dtypes."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    for col, dtype in DTYPE_MAP.items():
        if col in df.columns:
            try:
                df[col] = df[col].astype(dtype)
            except Exception:
                pass  # Keep original dtype if cast fails

    # Ensure Timestamp is datetime
    if COL_TIMESTAMP in df.columns and not pd.api.types.is_datetime64_any_dtype(df[COL_TIMESTAMP]):
        df[COL_TIMESTAMP] = pd.to_datetime(df[COL_TIMESTAMP], errors="coerce")

    # Drop rows with null comments
    before = len(df)
    df = df.dropna(subset=[COL_RAW_COMMENT])
    dropped = before - len(df)
    if dropped:
        logger.warning(f"Dropped {dropped:,} rows with null comments.")

    return df


def _print_summary(df: pd.DataFrame) -> None:
    """Print a quick summary of the loaded dataset."""
    logger.info("─" * 50)
    logger.info(f"  Shape          : {df.shape}")
    logger.info(f"  Memory usage   : {df.memory_usage(deep=True).sum() / 1e6:.1f} MB")
    logger.info(f"  Date range     : {df[COL_TIMESTAMP].min()} → {df[COL_TIMESTAMP].max()}")
    logger.info(f"  Brand counts   :\n{df[COL_BRAND_MENTION].value_counts()}")
    logger.info(f"  Nulls per col  :\n{df.isnull().sum()}")
    logger.info("─" * 50)


if __name__ == "__main__":
    # Quick smoke test with sample
    df = load_sample()
    print(df.head())
    print(df.dtypes)
