"""
preprocessing.py
─────────────────────────────────────────────────────────────
Complete NLP preprocessing pipeline for social media comments.

Pipeline stages:
  1. Noise Removal       — URLs, HTML tags, special chars
  2. Emoji Normalization — Convert emojis to text tokens
  3. Contraction Expand  — "can't" → "cannot"
  4. Case Normalisation  — Lowercase
  5. Tokenisation        — Word-level tokens
  6. Stop-word Removal   — NLTK English stopwords
  7. Lemmatisation       — WordNetLemmatizer
  8. Engagement Parsing  — Extract likes + replies to numeric
  9. Label Encoding      — VADER-based silver labels
─────────────────────────────────────────────────────────────
"""

import re
import string
import pandas as pd
import numpy as np
from typing import List, Optional

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer

import emoji
import contractions

from src.utils.config import (
    COL_TIMESTAMP, COL_RAW_COMMENT, COL_ENGAGEMENT, COL_BRAND_MENTION,
    COL_CLEAN_TEXT, COL_TOKENS, COL_SENTIMENT, COL_SENTIMENT_SCORE,
    COL_ENGAGEMENT_WEIGHT, LIKE_WEIGHT, REPLY_WEIGHT, ENGAGEMENT_SCALE_CAP,
    PROCESSED_FULL, RANDOM_SEED
)
from src.utils.logger import logger

# ── Download required NLTK data ───────────────────────────
_NLTK_PACKAGES = ["punkt", "stopwords", "wordnet", "vader_lexicon", "omw-1.4"]

def download_nltk_resources():
    for pkg in _NLTK_PACKAGES:
        try:
            nltk.data.find(f"tokenizers/{pkg}")
        except LookupError:
            nltk.download(pkg, quiet=True)

download_nltk_resources()

# ── Singletons ────────────────────────────────────────────
_lemmatizer  = WordNetLemmatizer()
_stop_words  = set(stopwords.words("english"))
_vader       = SentimentIntensityAnalyzer()

# Domain-specific stop words to KEEP (carry demand signal)
_DOMAIN_KEEP = {
    "not", "no", "never", "against", "best", "worst",
    "better", "worse", "love", "hate", "worth", "buy",
    "buying", "bought", "upgrade", "switch", "switching"
}
_EFFECTIVE_STOPWORDS = _stop_words - _DOMAIN_KEEP


# ═══════════════════════════════════════════════════════════
#  Stage 1 — Text Cleaning
# ═══════════════════════════════════════════════════════════

def remove_urls(text: str) -> str:
    return re.sub(r"https?://\S+|www\.\S+", " ", text)

def remove_html_tags(text: str) -> str:
    return re.sub(r"<[^>]+>", " ", text)

def remove_mentions_hashtags(text: str) -> str:
    return re.sub(r"[@#]\w+", " ", text)

def normalize_emojis(text: str) -> str:
    """Replace emojis with their textual description."""
    return emoji.demojize(text, delimiters=(" ", " "))

def expand_contractions(text: str) -> str:
    try:
        return contractions.fix(text)
    except Exception:
        return text

def remove_punctuation(text: str) -> str:
    # Keep apostrophes inside words; remove rest
    text = re.sub(r"[^\w\s']", " ", text)
    text = re.sub(r"\s'+\s*", " ", text)
    return text

def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()

def remove_repeated_chars(text: str) -> str:
    """Normalise 'loooove' → 'love'."""
    return re.sub(r"(.)\1{2,}", r"\1\1", text)


# ═══════════════════════════════════════════════════════════
#  Stage 2 — Tokenisation & Linguistic Processing
# ═══════════════════════════════════════════════════════════

def tokenize(text: str) -> List[str]:
    return word_tokenize(text.lower())

def remove_stopwords(tokens: List[str]) -> List[str]:
    return [t for t in tokens if t not in _EFFECTIVE_STOPWORDS and len(t) > 1]

def lemmatize(tokens: List[str]) -> List[str]:
    return [_lemmatizer.lemmatize(t) for t in tokens]

def remove_numeric_tokens(tokens: List[str], keep_model_numbers: bool = True) -> List[str]:
    """
    Remove pure numeric tokens.
    Keep product model numbers like 's26', 'iphone17'.
    """
    if keep_model_numbers:
        return [t for t in tokens if not t.isdigit()]
    return [t for t in tokens if not re.fullmatch(r"\d+", t)]


# ═══════════════════════════════════════════════════════════
#  Stage 3 — Engagement Feature Engineering
# ═══════════════════════════════════════════════════════════

def parse_engagement(value) -> dict:
    """
    Parse engagement string like '{"likes": 1200, "replies": 45}'
    or comma-separated 'likes:1200,replies:45'.

    Returns dict with keys 'likes' and 'replies'.
    """
    likes, replies = 0, 0
    try:
        if isinstance(value, str):
            # Try JSON-style
            likes_m  = re.search(r"likes[\"'\s:]*(\d+)", value, re.IGNORECASE)
            reply_m  = re.search(r"replies[\"'\s:]*(\d+)", value, re.IGNORECASE)
            likes    = int(likes_m.group(1)) if likes_m else 0
            replies  = int(reply_m.group(1)) if reply_m else 0
        elif isinstance(value, (int, float)):
            likes = int(value)
    except Exception:
        pass
    return {"likes": likes, "replies": replies}


def compute_engagement_weight(likes: int, replies: int) -> float:
    """
    Weighted engagement score.
    Capped at ENGAGEMENT_SCALE_CAP and normalised to [0, 1].
    """
    raw = (LIKE_WEIGHT * likes) + (REPLY_WEIGHT * replies)
    capped = min(raw, ENGAGEMENT_SCALE_CAP)
    return round(capped / ENGAGEMENT_SCALE_CAP, 6)


# ═══════════════════════════════════════════════════════════
#  Stage 4 — Sentiment Labelling (Silver Labels via VADER)
# ═══════════════════════════════════════════════════════════

def vader_sentiment(text: str) -> dict:
    """
    Returns compound score and integer label:
      2 = Positive  (compound >= 0.05)
      1 = Neutral   (-0.05 < compound < 0.05)
      0 = Negative  (compound <= -0.05)
    """
    scores = _vader.polarity_scores(text)
    compound = scores["compound"]
    if compound >= 0.05:
        label = 2
    elif compound <= -0.05:
        label = 0
    else:
        label = 1
    return {"compound": round(compound, 4), "label": label}


# ═══════════════════════════════════════════════════════════
#  Master Pipeline
# ═══════════════════════════════════════════════════════════

def clean_text(text: str) -> str:
    """Apply all text-cleaning stages and return clean string."""
    text = str(text)
    text = remove_urls(text)
    text = remove_html_tags(text)
    text = remove_mentions_hashtags(text)
    text = normalize_emojis(text)
    text = expand_contractions(text)
    text = remove_repeated_chars(text)
    text = remove_punctuation(text)
    text = normalize_whitespace(text)
    return text


def full_pipeline(text: str) -> List[str]:
    """
    Full preprocessing pipeline from raw text → clean token list.
    Used for Word2Vec training and BiLSTM input preparation.
    """
    clean = clean_text(text)
    tokens = tokenize(clean)
    tokens = remove_stopwords(tokens)
    tokens = lemmatize(tokens)
    tokens = remove_numeric_tokens(tokens)
    return tokens


def preprocess_dataframe(
    df: pd.DataFrame,
    use_vader: bool = True,
    save: bool = True,
) -> pd.DataFrame:
    """
    Apply the full preprocessing pipeline to an entire DataFrame.

    Parameters
    ----------
    df         : Input DataFrame with raw columns.
    use_vader  : Generate silver sentiment labels via VADER.
    save       : Persist the processed DataFrame to disk.

    Returns
    -------
    pd.DataFrame : Enriched DataFrame with all engineered features.
    """
    logger.info(f"Starting preprocessing on {len(df):,} rows ...")

    # ── Clean text ────────────────────────────────────────
    logger.info("Stage 1/4 — Text cleaning ...")
    df[COL_CLEAN_TEXT] = df[COL_RAW_COMMENT].apply(clean_text)

    # ── Tokenise ──────────────────────────────────────────
    logger.info("Stage 2/4 — Tokenisation & lemmatisation ...")
    df[COL_TOKENS] = df[COL_CLEAN_TEXT].apply(full_pipeline)

    # ── Engagement ────────────────────────────────────────
    logger.info("Stage 3/4 — Engagement feature engineering ...")
    eng_parsed = df[COL_ENGAGEMENT].apply(parse_engagement)
    df["Likes"]   = eng_parsed.apply(lambda x: x["likes"])
    df["Replies"] = eng_parsed.apply(lambda x: x["replies"])
    df[COL_ENGAGEMENT_WEIGHT] = df.apply(
        lambda r: compute_engagement_weight(r["Likes"], r["Replies"]), axis=1
    )

    # ── Sentiment ─────────────────────────────────────────
    if use_vader:
        logger.info("Stage 4/4 — VADER sentiment labelling ...")
        sentiment_results = df[COL_CLEAN_TEXT].apply(vader_sentiment)
        df[COL_SENTIMENT_SCORE] = sentiment_results.apply(lambda x: x["compound"])
        df[COL_SENTIMENT]       = sentiment_results.apply(lambda x: x["label"])

    # ── Token count ───────────────────────────────────────
    df["Token_Count"] = df[COL_TOKENS].apply(len)

    # ── Drop empty after preprocessing ───────────────────
    before = len(df)
    df = df[df["Token_Count"] >= 2].reset_index(drop=True)
    logger.info(f"Dropped {before - len(df):,} rows with <2 tokens after preprocessing.")

    logger.success(f"Preprocessing complete. Output shape: {df.shape}")

    if save:
        df.to_csv(PROCESSED_FULL, index=False)
        logger.success(f"Processed data saved → {PROCESSED_FULL}")

    return df


if __name__ == "__main__":
    from src.data.ingestion import load_sample
    df_sample = load_sample()
    df_processed = preprocess_dataframe(df_sample, save=True)
    print(df_processed[[COL_CLEAN_TEXT, COL_TOKENS, COL_SENTIMENT, COL_ENGAGEMENT_WEIGHT]].head(10))
