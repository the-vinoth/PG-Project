"""
bilstm_model.py
─────────────────────────────────────────────────────────────
Bidirectional LSTM (BiLSTM) sentiment classifier.

Architecture:
  Embedding (Word2Vec weights, trainable=False)
    → SpatialDropout1D
    → BiLSTM (return_sequences=True)
    → BiLSTM (return_sequences=False)
    → Dropout
    → Dense (ReLU)
    → BatchNormalization
    → Dense (Softmax) — 3 classes: Negative / Neutral / Positive

Input  : padded integer sequences of shape (batch, MAX_SEQ_LEN)
Output : class probabilities of shape (batch, 3)
─────────────────────────────────────────────────────────────
"""

import numpy as np
import json
from pathlib import Path

import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import (
    Embedding, SpatialDropout1D,
    Bidirectional, LSTM,
    Dense, Dropout, BatchNormalization,
    GlobalAveragePooling1D
)
from tensorflow.keras.callbacks import (
    EarlyStopping, ModelCheckpoint,
    ReduceLROnPlateau, TensorBoard
)
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_class_weight

from src.utils.config import (
    MAX_SEQUENCE_LENGTH, VOCAB_SIZE, W2V_EMBEDDING_DIM,
    BILSTM_UNITS, BILSTM_DROPOUT, BILSTM_RECURRENT_DROPOUT,
    BILSTM_DENSE_UNITS, NUM_CLASSES,
    BATCH_SIZE, EPOCHS, LEARNING_RATE, EARLY_STOPPING_PATIENCE,
    BILSTM_MODEL_FILE, CHECKPOINTS_DIR, METRICS_DIR,
    COL_SENTIMENT, RANDOM_SEED, VAL_SPLIT
)
from src.utils.logger import logger

tf.random.set_seed(RANDOM_SEED)


# ═══════════════════════════════════════════════════════════
#  Model Factory
# ═══════════════════════════════════════════════════════════

def build_bilstm_model(
    embedding_matrix: np.ndarray,
    max_seq_len: int = MAX_SEQUENCE_LENGTH,
    num_classes: int = NUM_CLASSES,
    trainable_embeddings: bool = False,
) -> tf.keras.Model:
    """
    Build and compile the BiLSTM sentiment model.

    Parameters
    ----------
    embedding_matrix      : Pre-trained Word2Vec weight matrix.
    max_seq_len           : Input sequence length.
    num_classes           : 3 (Negative / Neutral / Positive).
    trainable_embeddings  : Fine-tune embeddings during training.

    Returns
    -------
    tf.keras.Model : Compiled model.
    """
    vocab_size = embedding_matrix.shape[0]
    embed_dim  = embedding_matrix.shape[1]

    model = Sequential(name="BiLSTM_Sentiment_Classifier")

    # ── Embedding Layer ───────────────────────────────────
    model.add(Embedding(
        input_dim    = vocab_size,
        output_dim   = embed_dim,
        weights      = [embedding_matrix],
        input_length = max_seq_len,
        trainable    = trainable_embeddings,
        name         = "word2vec_embedding",
    ))
    model.add(SpatialDropout1D(0.2, name="spatial_dropout"))

    # ── BiLSTM Stack ──────────────────────────────────────
    model.add(Bidirectional(
        LSTM(
            units               = BILSTM_UNITS,
            dropout             = BILSTM_DROPOUT,
            recurrent_dropout   = BILSTM_RECURRENT_DROPOUT,
            return_sequences    = True,
        ),
        name="bilstm_1"
    ))
    model.add(Bidirectional(
        LSTM(
            units               = BILSTM_UNITS // 2,
            dropout             = BILSTM_DROPOUT,
            recurrent_dropout   = BILSTM_RECURRENT_DROPOUT,
            return_sequences    = False,
        ),
        name="bilstm_2"
    ))

    # ── Classification Head ───────────────────────────────
    model.add(Dropout(BILSTM_DROPOUT, name="dropout_1"))
    model.add(Dense(BILSTM_DENSE_UNITS, activation="relu", name="dense_1"))
    model.add(BatchNormalization(name="batch_norm"))
    model.add(Dropout(0.2, name="dropout_2"))
    model.add(Dense(num_classes, activation="softmax", name="output"))

    # ── Compile ───────────────────────────────────────────
    model.compile(
        optimizer = Adam(learning_rate=LEARNING_RATE),
        loss      = "sparse_categorical_crossentropy",
        metrics   = ["accuracy", tf.keras.metrics.AUC(name="auc", multi_label=False)],
    )

    logger.info(f"BiLSTM model built.")
    model.summary(print_fn=logger.info)
    return model


# ═══════════════════════════════════════════════════════════
#  Training
# ═══════════════════════════════════════════════════════════

def get_callbacks(model_name: str = "bilstm") -> list:
    """Prepare Keras training callbacks."""
    ckpt_path = CHECKPOINTS_DIR / f"{model_name}_best.h5"
    return [
        EarlyStopping(
            monitor              = "val_loss",
            patience             = EARLY_STOPPING_PATIENCE,
            restore_best_weights = True,
            verbose              = 1,
        ),
        ModelCheckpoint(
            filepath             = str(ckpt_path),
            monitor              = "val_accuracy",
            save_best_only       = True,
            verbose              = 1,
        ),
        ReduceLROnPlateau(
            monitor              = "val_loss",
            factor               = 0.5,
            patience             = 3,
            min_lr               = 1e-6,
            verbose              = 1,
        ),
    ]


def train_model(
    model: tf.keras.Model,
    X: np.ndarray,
    y: np.ndarray,
    val_data=None,
    use_class_weights: bool = True,
) -> tf.keras.callbacks.History:
    """
    Train the BiLSTM model.

    Parameters
    ----------
    model              : Compiled Keras model.
    X                  : Padded input sequences.
    y                  : Integer labels (0/1/2).
    val_data           : Optional (X_val, y_val) tuple.
    use_class_weights  : Balance imbalanced classes automatically.

    Returns
    -------
    History object.
    """
    if val_data is None:
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=VAL_SPLIT, random_state=RANDOM_SEED, stratify=y
        )
        val_data = (X_val, y_val)
    else:
        X_train, y_train = X, y

    class_weights = None
    if use_class_weights:
        classes = np.unique(y_train)
        weights = compute_class_weight("balanced", classes=classes, y=y_train)
        class_weights = dict(zip(classes.tolist(), weights.tolist()))
        logger.info(f"Class weights: {class_weights}")

    logger.info(f"Training BiLSTM | samples={len(X_train):,} | epochs={EPOCHS} | batch={BATCH_SIZE}")
    history = model.fit(
        X_train, y_train,
        validation_data  = val_data,
        epochs           = EPOCHS,
        batch_size       = BATCH_SIZE,
        class_weight     = class_weights,
        callbacks        = get_callbacks(),
        verbose          = 1,
    )

    # Save final model
    BILSTM_MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    model.save(str(BILSTM_MODEL_FILE))
    logger.success(f"Trained model saved → {BILSTM_MODEL_FILE}")

    return history


def load_bilstm_model(filepath: Path = BILSTM_MODEL_FILE) -> tf.keras.Model:
    """Load a saved BiLSTM model."""
    if not filepath.exists():
        raise FileNotFoundError(f"Model not found at {filepath}. Train first.")
    logger.info(f"Loading BiLSTM model from {filepath}")
    return load_model(str(filepath))


def save_metrics(history: tf.keras.callbacks.History, filename: str = "bilstm_metrics.json"):
    """Persist training history metrics to JSON."""
    metrics_path = METRICS_DIR / filename
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    # Convert numpy floats to Python floats for JSON serialisation
    serialisable = {k: [float(v) for v in vals] for k, vals in history.history.items()}
    with open(metrics_path, "w") as f:
        json.dump(serialisable, f, indent=2)
    logger.success(f"Training metrics saved → {metrics_path}")


if __name__ == "__main__":
    from src.data.ingestion import load_sample
    from src.data.preprocessing import preprocess_dataframe
    from src.features.word2vec_embeddings import (
        train_word2vec, build_tokenizer, build_embedding_matrix, encode_sequences
    )
    from src.utils.config import COL_TOKENS, MAX_SEQUENCE_LENGTH

    df       = load_sample()
    df       = preprocess_dataframe(df, save=False)
    corpus   = df[COL_TOKENS].tolist()

    w2v      = train_word2vec(corpus, save=True)
    word2idx = build_tokenizer(corpus)
    emb_mat  = build_embedding_matrix(word2idx, w2v)
    X        = encode_sequences(corpus, word2idx, MAX_SEQUENCE_LENGTH)
    y        = df[COL_SENTIMENT].values

    model    = build_bilstm_model(emb_mat)
    history  = train_model(model, X, y)
    save_metrics(history)
