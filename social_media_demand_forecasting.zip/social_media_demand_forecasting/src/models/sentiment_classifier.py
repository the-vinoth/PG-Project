"""
sentiment_classifier.py
─────────────────────────────────────────────────────────────
Inference wrapper for the trained BiLSTM sentiment classifier.

Provides:
  - Single-comment inference
  - Batch inference on DataFrames
  - Confidence scores per class
  - Purchase intent scoring (extension of sentiment)
─────────────────────────────────────────────────────────────
"""

import numpy as np
import pandas as pd
import joblib
from pathlib import Path
from typing import List, Union, Optional

from src.models.bilstm_model import load_bilstm_model
from src.data.preprocessing import clean_text, full_pipeline
from src.features.word2vec_embeddings import encode_sequences
from src.utils.config import (
    MAX_SEQUENCE_LENGTH, SENTIMENT_LABELS, MODELS_DIR,
    COL_RAW_COMMENT, COL_CLEAN_TEXT, COL_TOKENS,
    COL_SENTIMENT, COL_SENTIMENT_SCORE
)
from src.utils.logger import logger

# ── Purchase intent keywords ───────────────────────────────
INTENT_KEYWORDS = {
    "strong_buy" : ["buy", "buying", "purchased", "ordered", "preorder", "upgrade",
                    "switching", "worth it", "getting this", "just bought"],
    "consider"   : ["thinking", "considering", "maybe", "might buy", "could buy",
                    "should i get", "is it worth"],
    "negative"   : ["not buying", "overpriced", "pass", "skip", "disappointed",
                    "waste of money", "returning"],
}


class SentimentClassifier:
    """
    Inference-ready wrapper around the trained BiLSTM model.

    Usage
    -----
    >>> clf = SentimentClassifier()
    >>> clf.predict("The S26 Ultra camera is absolutely stunning!")
    {'label': 'Positive', 'confidence': 0.94, 'intent': 'consider'}
    """

    def __init__(self):
        self.model     = None
        self.word2idx  = None
        self._loaded   = False

    def load(self):
        """Lazy-load model and tokenizer artifacts."""
        if self._loaded:
            return self

        logger.info("Loading BiLSTM sentiment classifier ...")
        self.model    = load_bilstm_model()
        w2idx_path    = MODELS_DIR / "word2idx.pkl"

        if not w2idx_path.exists():
            raise FileNotFoundError(
                f"word2idx.pkl not found at {w2idx_path}. "
                "Please run Notebook 03 to generate this artifact."
            )

        self.word2idx = joblib.load(w2idx_path)
        self._loaded  = True
        logger.success("Classifier loaded and ready.")
        return self

    # ── Core prediction ────────────────────────────────────

    def _preprocess(self, texts: List[str]) -> np.ndarray:
        """Clean and encode a list of raw texts."""
        token_lists = [full_pipeline(t) for t in texts]
        return encode_sequences(token_lists, self.word2idx, MAX_SEQUENCE_LENGTH)

    def predict(self, text: str) -> dict:
        """
        Predict sentiment for a single comment.

        Returns
        -------
        dict : label, confidence, probabilities, intent_signal
        """
        self.load()
        X         = self._preprocess([text])
        probs     = self.model.predict(X, verbose=0)[0]
        label_idx = int(np.argmax(probs))
        label     = SENTIMENT_LABELS[label_idx]
        confidence= float(probs[label_idx])
        intent    = self._detect_intent(text.lower())

        return {
            "label"      : label,
            "confidence" : round(confidence, 4),
            "probabilities": {
                "Negative" : round(float(probs[0]), 4),
                "Neutral"  : round(float(probs[1]), 4),
                "Positive" : round(float(probs[2]), 4),
            },
            "intent_signal": intent,
        }

    def predict_batch(
        self,
        df: pd.DataFrame,
        text_col: str = COL_RAW_COMMENT,
        batch_size: int = 512,
    ) -> pd.DataFrame:
        """
        Run batch inference on a DataFrame.

        Adds columns:
          - BiLSTM_Sentiment  : Predicted label (string)
          - BiLSTM_Confidence : Confidence score (float)
          - Purchase_Intent   : Intent signal string
          - Prob_Negative/Neutral/Positive : Class probabilities

        Returns
        -------
        pd.DataFrame : Input DataFrame with new prediction columns appended.
        """
        self.load()

        texts = df[text_col].fillna("").tolist()
        X     = self._preprocess(texts)

        logger.info(f"Running batch inference on {len(texts):,} comments ...")
        all_probs = self.model.predict(X, batch_size=batch_size, verbose=1)

        df = df.copy()
        df["BiLSTM_Label"]      = all_probs.argmax(axis=1)
        df["BiLSTM_Sentiment"]  = df["BiLSTM_Label"].map(SENTIMENT_LABELS)
        df["BiLSTM_Confidence"] = all_probs.max(axis=1).round(4)
        df["Prob_Negative"]     = all_probs[:, 0].round(4)
        df["Prob_Neutral"]      = all_probs[:, 1].round(4)
        df["Prob_Positive"]     = all_probs[:, 2].round(4)
        df["Purchase_Intent"]   = [self._detect_intent(t.lower()) for t in texts]

        logger.success("Batch inference complete.")
        return df

    # ── Purchase intent detection ──────────────────────────

    def _detect_intent(self, text: str) -> str:
        """
        Keyword-based purchase intent classifier.

        Returns
        -------
        str : 'strong_buy' | 'consider' | 'negative_intent' | 'neutral'
        """
        for signal, keywords in INTENT_KEYWORDS.items():
            if any(kw in text for kw in keywords):
                return signal
        return "neutral"

    def compute_purchase_intent_score(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Compute a numeric Purchase Intent Score (0–1) per comment.

        Score = BiLSTM_Confidence × intent_multiplier

        Intent multipliers:
          strong_buy      → 1.0
          consider        → 0.6
          neutral         → 0.3
          negative_intent → 0.0
        """
        MULTIPLIERS = {
            "strong_buy"     : 1.0,
            "consider"       : 0.6,
            "neutral"        : 0.3,
            "negative_intent": 0.0,
        }
        if "Purchase_Intent" not in df.columns or "BiLSTM_Confidence" not in df.columns:
            raise ValueError("Run predict_batch() before calling this method.")

        df = df.copy()
        df["Intent_Multiplier"]     = df["Purchase_Intent"].map(MULTIPLIERS).fillna(0.3)
        df["Purchase_Intent_Score"] = (
            df["BiLSTM_Confidence"] *
            df["Intent_Multiplier"] *
            (df["BiLSTM_Label"] == 2).astype(float)   # Positive label only
        ).round(4)

        logger.info(f"Purchase intent scores computed. "
                    f"Mean={df['Purchase_Intent_Score'].mean():.4f} | "
                    f"Max={df['Purchase_Intent_Score'].max():.4f}")
        return df


# ── Convenience factory ────────────────────────────────────

def get_classifier() -> SentimentClassifier:
    """Return a loaded SentimentClassifier instance."""
    return SentimentClassifier().load()


if __name__ == "__main__":
    test_comments = [
        "Just ordered the Samsung S26 Ultra — can't wait for delivery!",
        "Camera quality looks good but I'm not sure if it's worth the price",
        "Terrible build quality, returning mine tomorrow",
        "Just saw the unboxing, might buy this next month",
        "Completely neutral comment about the weather today",
    ]

    clf = SentimentClassifier().load()
    print("\n=== Single-comment inference demo ===\n")
    for comment in test_comments:
        result = clf.predict(comment)
        print(f"Comment : {comment[:60]}")
        print(f"  Label     : {result['label']} ({result['confidence']:.2%} confident)")
        print(f"  Intent    : {result['intent_signal']}")
        print(f"  Probs     : {result['probabilities']}")
        print()
