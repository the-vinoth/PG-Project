"""
demand_forecaster.py
─────────────────────────────────────────────────────────────
Time-series demand forecasting layer.

Two forecasting strategies:
  1. ARIMA   — short-term (7–14 day) precision forecasting
  2. Prophet — long-term (30 day) trend + seasonality modelling

Input  : daily aggregated demand scores per brand
Output : forecasted demand CSVs + metrics
─────────────────────────────────────────────────────────────
"""

import json
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional, Tuple

from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller
from prophet import Prophet

from sklearn.metrics import mean_absolute_error, mean_squared_error

from src.utils.config import (
    ARIMA_ORDER, FORECAST_HORIZON_DAYS, PROPHET_SEASONALITY,
    COL_BRAND_MENTION, COL_TIMESTAMP,
    PREDICTIONS_DIR, METRICS_DIR, TARGET_BRAND, ALL_BRANDS
)
from src.utils.logger import logger

warnings.filterwarnings("ignore")


# ═══════════════════════════════════════════════════════════
#  Stationarity Check
# ═══════════════════════════════════════════════════════════

def adf_test(series: pd.Series) -> dict:
    """
    Augmented Dickey-Fuller test for stationarity.

    Returns
    -------
    dict : adf_stat, p_value, is_stationary
    """
    result = adfuller(series.dropna(), autolag="AIC")
    is_stationary = result[1] < 0.05
    logger.info(f"ADF Test | stat={result[0]:.4f} | p={result[1]:.4f} | stationary={is_stationary}")
    return {
        "adf_statistic" : round(result[0], 4),
        "p_value"       : round(result[1], 6),
        "is_stationary" : is_stationary,
    }


# ═══════════════════════════════════════════════════════════
#  ARIMA Forecaster
# ═══════════════════════════════════════════════════════════

def forecast_arima(
    series: pd.Series,
    horizon: int = FORECAST_HORIZON_DAYS,
    order: tuple = ARIMA_ORDER,
) -> Tuple[pd.DataFrame, dict]:
    """
    Fit ARIMA model and generate horizon-day forecast.

    Parameters
    ----------
    series  : Daily demand time series (indexed by date).
    horizon : Forecast horizon in days.
    order   : ARIMA (p, d, q) order.

    Returns
    -------
    (forecast_df, metrics_dict)
    """
    logger.info(f"Fitting ARIMA{order} | series length={len(series)} | horizon={horizon}")

    # Train / test split (last 20% for evaluation)
    split = int(len(series) * 0.8)
    train, test = series.iloc[:split], series.iloc[split:]

    # Fit
    arima_model = ARIMA(train, order=order).fit()

    # Evaluate on test set
    test_preds = arima_model.forecast(steps=len(test))
    mae  = mean_absolute_error(test, test_preds)
    rmse = np.sqrt(mean_squared_error(test, test_preds))
    mape = np.mean(np.abs((test.values - test_preds.values) / (test.values + 1e-9))) * 100
    logger.info(f"ARIMA test evaluation | MAE={mae:.4f} | RMSE={rmse:.4f} | MAPE={mape:.2f}%")

    # Refit on full series, forecast future
    full_model = ARIMA(series, order=order).fit()
    future_preds = full_model.forecast(steps=horizon)

    last_date  = series.index[-1]
    future_idx = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=horizon, freq="D")
    forecast_df = pd.DataFrame({
        "ds"            : future_idx,
        "yhat_arima"    : future_preds.values,
        "model"         : "ARIMA",
    })

    metrics = {"model": "ARIMA", "order": order, "MAE": round(mae, 4),
               "RMSE": round(rmse, 4), "MAPE": round(mape, 2)}
    return forecast_df, metrics


# ═══════════════════════════════════════════════════════════
#  Prophet Forecaster
# ═══════════════════════════════════════════════════════════

def forecast_prophet(
    series: pd.Series,
    horizon: int = FORECAST_HORIZON_DAYS,
    seasonality: str = PROPHET_SEASONALITY,
) -> Tuple[pd.DataFrame, dict]:
    """
    Fit Facebook Prophet and generate horizon-day forecast with
    uncertainty intervals.

    Parameters
    ----------
    series      : Daily demand time series (date-indexed).
    horizon     : Forecast horizon in days.
    seasonality : 'daily', 'weekly', 'yearly'.

    Returns
    -------
    (forecast_df, metrics_dict)
    """
    logger.info(f"Fitting Prophet | series length={len(series)} | horizon={horizon}")

    # Prophet expects a DataFrame with 'ds' and 'y' columns
    df_prophet = pd.DataFrame({"ds": series.index, "y": series.values})

    # Train/test split
    split      = int(len(df_prophet) * 0.8)
    train_p    = df_prophet.iloc[:split]
    test_p     = df_prophet.iloc[split:]

    model = Prophet(
        daily_seasonality  = (seasonality == "daily"),
        weekly_seasonality = (seasonality == "weekly"),
        yearly_seasonality = (seasonality == "yearly"),
        uncertainty_samples= 500,
        changepoint_prior_scale = 0.05,
    )
    model.fit(train_p)

    # Evaluate
    future_test  = model.make_future_dataframe(periods=len(test_p))
    test_forecast = model.predict(future_test)
    test_yhat    = test_forecast.iloc[split:]["yhat"].values
    mae  = mean_absolute_error(test_p["y"].values, test_yhat)
    rmse = np.sqrt(mean_squared_error(test_p["y"].values, test_yhat))
    mape = np.mean(np.abs((test_p["y"].values - test_yhat) / (test_p["y"].values + 1e-9))) * 100
    logger.info(f"Prophet test evaluation | MAE={mae:.4f} | RMSE={rmse:.4f} | MAPE={mape:.2f}%")

    # Refit on full data, forecast future
    full_model = Prophet(
        weekly_seasonality = True,
        changepoint_prior_scale = 0.05,
        uncertainty_samples= 500,
    )
    full_model.fit(df_prophet)
    future     = full_model.make_future_dataframe(periods=horizon)
    forecast   = full_model.predict(future).tail(horizon)

    forecast_df = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
    forecast_df.rename(columns={"yhat": "yhat_prophet"}, inplace=True)
    forecast_df["model"] = "Prophet"

    metrics = {"model": "Prophet", "MAE": round(mae, 4),
               "RMSE": round(rmse, 4), "MAPE": round(mape, 2)}
    return forecast_df, metrics


# ═══════════════════════════════════════════════════════════
#  Full Forecasting Pipeline per Brand
# ═══════════════════════════════════════════════════════════

def run_brand_forecast(
    daily_df: pd.DataFrame,
    brand: str = TARGET_BRAND,
    horizon: int = FORECAST_HORIZON_DAYS,
) -> pd.DataFrame:
    """
    Run both ARIMA and Prophet forecasts for a given brand.

    Parameters
    ----------
    daily_df : Output of aggregate_demand_by_brand().
    brand    : Brand name to forecast.
    horizon  : Days to forecast ahead.

    Returns
    -------
    pd.DataFrame : Merged ARIMA + Prophet forecast.
    """
    logger.info(f"\n{'='*50}\n  Forecasting demand for: {brand}\n{'='*50}")

    brand_df = daily_df[daily_df[COL_BRAND_MENTION] == brand].copy()
    brand_df = brand_df.set_index("Timestamp").sort_index()
    series   = brand_df["Avg_Demand"].asfreq("D").fillna(method="ffill")

    if len(series) < 10:
        logger.warning(f"Insufficient data for '{brand}' ({len(series)} days). Skipping.")
        return pd.DataFrame()

    # Stationarity check
    adf_test(series)

    # ARIMA
    arima_df, arima_metrics = forecast_arima(series, horizon=horizon)

    # Prophet
    prophet_df, prophet_metrics = forecast_prophet(series, horizon=horizon)

    # Merge
    merged = arima_df.merge(
        prophet_df[["ds", "yhat_prophet", "yhat_lower", "yhat_upper"]],
        on="ds", how="outer"
    )
    merged["Brand"]    = brand
    merged["Ensemble"] = merged[["yhat_arima", "yhat_prophet"]].mean(axis=1)

    # Save
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    out_file = PREDICTIONS_DIR / f"forecast_{brand.replace(' ', '_')}.csv"
    merged.to_csv(out_file, index=False)
    logger.success(f"Forecast saved → {out_file}")

    # Save metrics
    all_metrics = {"brand": brand, "ARIMA": arima_metrics, "Prophet": prophet_metrics}
    metrics_file = METRICS_DIR / f"forecast_metrics_{brand.replace(' ', '_')}.json"
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    with open(metrics_file, "w") as f:
        json.dump(all_metrics, f, indent=2)
    logger.success(f"Forecast metrics saved → {metrics_file}")

    return merged


def run_all_brand_forecasts(daily_df: pd.DataFrame) -> dict:
    """Run forecasts for all brands and return a dict of results."""
    results = {}
    for brand in ALL_BRANDS:
        try:
            results[brand] = run_brand_forecast(daily_df, brand=brand)
        except Exception as e:
            logger.error(f"Forecast failed for '{brand}': {e}")
    return results


if __name__ == "__main__":
    from src.data.ingestion import load_sample
    from src.data.preprocessing import preprocess_dataframe
    from src.features.engagement_weighting import compute_demand_score, aggregate_demand_by_brand

    df  = load_sample()
    df  = preprocess_dataframe(df, save=False)
    df  = compute_demand_score(df)
    agg = aggregate_demand_by_brand(df)

    results = run_all_brand_forecasts(agg)
    for brand, forecast in results.items():
        if not forecast.empty:
            print(f"\n{brand}:")
            print(forecast.head())
