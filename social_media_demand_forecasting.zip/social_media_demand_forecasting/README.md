# 📊 Social Media Big Data Analysis for Demand Forecasting

> **M.Sc. Data Science Capstone Project**  
> End-to-End NLP + Deep Learning Pipeline for Real-Time Demand Intelligence

---

## 🧭 Project Overview

This project builds a **production-grade, end-to-end demand forecasting system** powered by social media big data. By harvesting and analyzing over **1.6 million YouTube tech-channel comments**, the system extracts consumer sentiment, purchase intent, and brand migration signals — enabling businesses to forecast product demand with high accuracy.

**Target Product:** Samsung S26 Ultra vs. Competitor Products (iPhone 17, Pixel 9, etc.)

---

## 🗂️ Project Structure

```
social_media_demand_forecasting/
│
├── data/
│   ├── raw/                    # Original extracted CSV files (1.6M rows)
│   ├── processed/              # Cleaned, tokenized, encoded datasets
│   └── samples/                # 10,000-row stratified sample for dev/testing
│
├── models/
│   ├── saved/                  # Final trained model artifacts (.h5, .pkl)
│   └── checkpoints/            # Training checkpoints for resumability
│
├── notebooks/
│   ├── 01_EDA.ipynb            # Exploratory Data Analysis
│   ├── 02_Preprocessing.ipynb  # Text preprocessing pipeline
│   ├── 03_Word2Vec.ipynb       # Word embedding training
│   ├── 04_BiLSTM_Training.ipynb# BiLSTM sentiment model
│   ├── 05_Forecasting.ipynb    # Demand forecasting with time series
│   └── 06_Evaluation.ipynb     # Full model evaluation & reporting
│
├── src/
│   ├── data/
│   │   ├── __init__.py
│   │   ├── ingestion.py        # Data loading & sampling utilities
│   │   └── preprocessing.py    # Full NLP preprocessing pipeline
│   ├── features/
│   │   ├── __init__.py
│   │   ├── word2vec_embeddings.py  # Word2Vec training & inference
│   │   └── engagement_weighting.py # Engagement-score feature engineering
│   ├── models/
│   │   ├── __init__.py
│   │   ├── bilstm_model.py     # BiLSTM model architecture
│   │   ├── sentiment_classifier.py # Sentiment classification logic
│   │   └── demand_forecaster.py    # ARIMA/Prophet time-series layer
│   ├── visualization/
│   │   ├── __init__.py
│   │   └── plots.py            # All plotting & dashboard utilities
│   └── utils/
│       ├── __init__.py
│       ├── config.py           # Central config (paths, hyperparameters)
│       └── logger.py           # Logging utility
│
├── outputs/
│   ├── figures/                # All generated charts and plots
│   ├── predictions/            # Model output CSVs
│   └── metrics/                # Evaluation metric JSONs
│
├── reports/
│   ├── figures/                # High-res report figures
│   └── final/                  # Final project report (PDF/DOCX)
│
├── README.md                   ← You are here
└── requirements.txt            # All Python dependencies
```

---

## 🔬 Technical Architecture

```
Raw Social Media Data (1.6M rows)
        ↓
[ Data Ingestion & Stratified Sampling ]
        ↓
[ NLP Preprocessing Pipeline ]
  - Noise Removal / Emoji Normalization
  - Tokenization
  - Stop-word Removal
  - Lemmatization
        ↓
[ Feature Engineering ]
  - Word2Vec Embeddings (300-dim)
  - Engagement Weighting (Likes × Replies)
  - Brand Mention Extraction
        ↓
[ BiLSTM Sentiment Classifier ]
  - Positive / Negative / Neutral
  - Purchase Intent Detection
        ↓
[ Demand Forecasting Layer ]
  - Time-Series Aggregation (Daily/Weekly)
  - ARIMA / Facebook Prophet
        ↓
[ Outputs & Reports ]
  - Demand Trend Charts
  - Brand Comparison Dashboard
  - Forecasted Demand CSV
```

---

## ⚙️ Setup & Installation

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/social_media_demand_forecasting.git
cd social_media_demand_forecasting

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install all dependencies
pip install -r requirements.txt

# 4. Place your dataset
# → Put full 1.6M CSV in:       data/raw/
# → Put 10k sample CSV in:      data/samples/

# 5. Run preprocessing
python src/data/preprocessing.py

# 6. Train Word2Vec embeddings
python src/features/word2vec_embeddings.py

# 7. Train BiLSTM model
python src/models/bilstm_model.py

# 8. Run demand forecasting
python src/models/demand_forecaster.py
```

---

## 📓 Notebook Execution Order

| Step | Notebook | Description |
|------|----------|-------------|
| 1 | `01_EDA.ipynb` | Dataset exploration, distributions, brand mentions |
| 2 | `02_Preprocessing.ipynb` | Full pipeline: clean → tokenize → encode |
| 3 | `03_Word2Vec.ipynb` | Train & visualize Word2Vec embeddings |
| 4 | `04_BiLSTM_Training.ipynb` | Model training, loss curves, confusion matrix |
| 5 | `05_Forecasting.ipynb` | Time-series demand forecasting |
| 6 | `06_Evaluation.ipynb` | Metrics, reports, final visualizations |

---

## 📊 Dataset Profile

| Property | Value |
|----------|-------|
| Total Records | 1,600,000+ rows |
| Source | YouTube Tech Channel Comments |
| Timeframe | Last 3–6 months |
| Format | `.csv` |
| Key Features | Timestamp, Raw_Comment, Engagement_Metrics, Brand_Mention |

**Sample for development:** `data/samples/sample_10k.csv` (10,000 rows — stratified)

---

## 🧠 Models Used

| Model | Purpose | Library |
|-------|---------|---------|
| Word2Vec (Skip-gram) | Text embeddings | `gensim` |
| BiLSTM | Sentiment classification | `tensorflow/keras` |
| ARIMA | Short-term demand forecasting | `statsmodels` |
| Facebook Prophet | Long-term trend forecasting | `prophet` |
| VADER | Baseline sentiment (lexicon) | `nltk` |

---

## 📈 Key Outputs

- `outputs/predictions/demand_forecast.csv` — Forecasted daily demand scores
- `outputs/figures/sentiment_trend.png` — Sentiment over time
- `outputs/figures/brand_comparison.png` — Samsung vs. competitors
- `outputs/metrics/bilstm_metrics.json` — Accuracy, F1, AUC scores
- `reports/final/` — Final M.Sc. project report

---

## 👤 Author

**[Your Name]**  
M.Sc. Data Science  
[Your University Name]  
[Year]

---

## 📄 License

This project is developed for academic purposes as part of an M.Sc. Data Science dissertation.
