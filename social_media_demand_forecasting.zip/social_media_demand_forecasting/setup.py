"""
setup.py
─────────────────────────────────────────────────────────────
Makes the project installable as a local package so that
`from src.xxx import yyy` works without sys.path hacks.

Install with:  pip install -e .
─────────────────────────────────────────────────────────────
"""

from setuptools import setup, find_packages

setup(
    name            = "social_media_demand_forecasting",
    version         = "1.0.0",
    description     = "M.Sc. Data Science — Social Media Big Data Analysis for Demand Forecasting",
    author          = "Your Name",
    python_requires = ">=3.9",
    packages        = find_packages(exclude=["notebooks", "reports", "data", "outputs"]),
    install_requires= [
        "numpy>=1.26",
        "pandas>=2.2",
        "matplotlib>=3.8",
        "seaborn>=0.13",
        "nltk>=3.8",
        "gensim>=4.3",
        "tensorflow>=2.16",
        "statsmodels>=0.14",
        "prophet>=1.1",
        "scikit-learn>=1.4",
        "loguru>=0.7",
        "emoji>=2.11",
        "contractions>=0.1",
        "tqdm>=4.66",
        "joblib>=1.4",
        "wordcloud>=1.9",
    ],
    classifiers = [
        "Programming Language :: Python :: 3",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
