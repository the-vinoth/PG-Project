"""
run_colab_full_pipeline.py
─────────────────────────────────────────────────────────────
Google Colab GPU execution script for the full 1.6M dataset.

This script orchestrates the complete end-to-end pipeline:
  1. Mount Google Drive
  2. Install dependencies
  3. Load & preprocess the full 1.6M dataset
  4. Train Word2Vec embeddings
  5. Train BiLSTM sentiment classifier
  6. Run demand forecasting
  7. Generate all output figures and reports

Designed to run top-to-bottom in a Colab GPU runtime.
Runtime estimate: ~2–4 hours on Colab Pro (T4/A100).
─────────────────────────────────────────────────────────────
"""

# ════════════════════════════════════════════════════════════
# CELL 1 — Mount Drive & Clone/Upload Project
# ════════════════════════════════════════════════════════════
"""
# Run this cell first in Colab:

from google.colab import drive
drive.mount('/content/drive')

# If project is zipped on Drive:
import shutil, os
shutil.unpack_archive('/content/drive/MyDrive/social_media_demand_forecasting.zip',
                      '/content/project')
os.chdir('/content/project')
"""

# ════════════════════════════════════════════════════════════
# CELL 2 — Install Dependencies
# ════════════════════════════════════════════════════════════
"""
%%capture
!pip install -r requirements.txt
"""

# ════════════════════════════════════════════════════════════
# CELL 3 — Verify GPU
# ════════════════════════════════════════════════════════════
"""
import tensorflow as tf
print("TF version  :", tf.__version__)
print("GPU devices :", tf.config.list_physical_devices('GPU'))
"""

# ════════════════════════════════════════════════════════════
# CELL 4 — Run Full Pipeline
# ════════════════════════════════════════════════════════════

import sys
import os
import time
import numpy as np
import pandas as pd

# Adjust if running from Colab
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.utils.logger import logger
from src.utils.config import (
    RAW_DATA_FILE, PROCESSED_FULL, MODELS_DIR,
    COL_TOKENS, COL_SENTIMENT, MAX_SEQUENCE_LENGTH
)

# ────────────────────────────────────────────────────────────
# Step 1: Load full 1.6M dataset (chunked for memory safety)
# ────────────────────────────────────────────────────────────
def step1_load():
    logger.info("=" * 60)
    logger.info("STEP 1: Loading full 1.6M dataset ...")
    logger.info("=" * 60)

    from src.data.ingestion import load_raw_data
    df = load_raw_data(filepath=RAW_DATA_FILE, chunksize=100_000)
    logger.success(f"Dataset loaded: {len(df):,} rows")
    return df


# ────────────────────────────────────────────────────────────
# Step 2: Full preprocessing
# ────────────────────────────────────────────────────────────
def step2_preprocess(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("=" * 60)
    logger.info("STEP 2: NLP Preprocessing Pipeline ...")
    logger.info("=" * 60)

    from src.data.preprocessing import preprocess_dataframe
    t0 = time.time()
    df = preprocess_dataframe(df, use_vader=True, save=True)
    logger.success(f"Preprocessing complete in {(time.time()-t0)/60:.1f} min. Shape: {df.shape}")
    return df


# ────────────────────────────────────────────────────────────
# Step 3: Word2Vec training
# ────────────────────────────────────────────────────────────
def step3_word2vec(df: pd.DataFrame):
    logger.info("=" * 60)
    logger.info("STEP 3: Training Word2Vec Embeddings ...")
    logger.info("=" * 60)

    import ast
    from src.features.word2vec_embeddings import (
        train_word2vec, build_tokenizer, build_embedding_matrix, encode_sequences
    )

    corpus = df[COL_TOKENS].apply(
        lambda x: ast.literal_eval(x) if isinstance(x, str) else x
    ).tolist()

    t0 = time.time()
    w2v_model  = train_word2vec(corpus, save=True)
    word2idx   = build_tokenizer(corpus)
    emb_matrix = build_embedding_matrix(word2idx, w2v_model)

    import joblib
    joblib.dump(word2idx, MODELS_DIR / "word2idx.pkl")
    np.save(MODELS_DIR / "embedding_matrix.npy", emb_matrix)
    logger.success(f"Word2Vec done in {(time.time()-t0)/60:.1f} min.")

    X = encode_sequences(corpus, word2idx, MAX_SEQUENCE_LENGTH)
    np.save(MODELS_DIR / "X_sequences.npy", X)
    logger.success(f"Sequences encoded and saved. Shape: {X.shape}")

    return w2v_model, word2idx, emb_matrix, X


# ────────────────────────────────────────────────────────────
# Step 4: BiLSTM training
# ────────────────────────────────────────────────────────────
def step4_bilstm(emb_matrix: np.ndarray, X: np.ndarray, y: np.ndarray):
    logger.info("=" * 60)
    logger.info("STEP 4: Training BiLSTM Sentiment Classifier ...")
    logger.info("=" * 60)

    from src.models.bilstm_model import build_bilstm_model, train_model, save_metrics

    model   = build_bilstm_model(emb_matrix)
    t0      = time.time()
    history = train_model(model, X, y, use_class_weights=True)
    save_metrics(history)
    logger.success(f"BiLSTM training done in {(time.time()-t0)/60:.1f} min.")
    return model, history


# ────────────────────────────────────────────────────────────
# Step 5: Demand forecasting
# ────────────────────────────────────────────────────────────
def step5_forecast(df: pd.DataFrame):
    logger.info("=" * 60)
    logger.info("STEP 5: Demand Forecasting ...")
    logger.info("=" * 60)

    from src.features.engagement_weighting import (
        compute_demand_score, aggregate_demand_by_brand
    )
    from src.models.demand_forecaster import run_all_brand_forecasts

    df        = compute_demand_score(df)
    daily_df  = aggregate_demand_by_brand(df)
    forecasts = run_all_brand_forecasts(daily_df)
    logger.success("All brand forecasts complete.")
    return forecasts


# ────────────────────────────────────────────────────────────
# Step 6: Generate report figures
# ────────────────────────────────────────────────────────────
def step6_visualize(df: pd.DataFrame, daily_df: pd.DataFrame, history):
    logger.info("=" * 60)
    logger.info("STEP 6: Generating Output Figures ...")
    logger.info("=" * 60)

    from src.visualization.plots import (
        plot_sentiment_distribution, plot_demand_trend,
        plot_brand_comparison, plot_training_history,
        plot_engagement_sentiment
    )
    import matplotlib
    matplotlib.use("Agg")  # Non-interactive backend for Colab

    plot_sentiment_distribution(df)
    plot_demand_trend(daily_df)
    plot_brand_comparison(daily_df)
    plot_engagement_sentiment(df)
    if history:
        plot_training_history(history.history)

    logger.success("All figures saved to outputs/figures/")


# ════════════════════════════════════════════════════════════
# MAIN ORCHESTRATOR
# ════════════════════════════════════════════════════════════

def main():
    pipeline_start = time.time()
    logger.info("🚀 Starting Full End-to-End Pipeline on 1.6M Dataset")

    # Step 1: Load
    df = step1_load()

    # Step 2: Preprocess
    df = step2_preprocess(df)

    # Step 3: Word2Vec
    w2v_model, word2idx, emb_matrix, X = step3_word2vec(df)

    # Step 4: BiLSTM
    import ast
    df[COL_TOKENS] = df[COL_TOKENS].apply(
        lambda x: ast.literal_eval(x) if isinstance(x, str) else x
    )
    y              = df[COL_SENTIMENT].values
    model, history = step4_bilstm(emb_matrix, X, y)

    # Step 5: Forecasting
    from src.features.engagement_weighting import compute_demand_score, aggregate_demand_by_brand
    df           = compute_demand_score(df)
    daily_df     = aggregate_demand_by_brand(df)
    forecasts    = step5_forecast(df)

    # Step 6: Visualise
    step6_visualize(df, daily_df, history)

    total_min = (time.time() - pipeline_start) / 60
    logger.success(f"\n✅ PIPELINE COMPLETE in {total_min:.1f} minutes")
    logger.success("Outputs → outputs/figures/ | outputs/predictions/ | outputs/metrics/")
    logger.success("Models  → models/saved/")


if __name__ == "__main__":
    main()
